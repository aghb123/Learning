VLOOK™ 支持「**衬线**」与「**非衬线**」两套字体风格，可根据个人喜好进行切换，后续将会引入更多字体风格
。

衬线与非衬线分别优先使用开源的「**思源黑体**」和「思源宋体」，建议下载安装获得最佳的视觉体验。

==下载地址：==

**【思源黑体 / Noto Sans】**

  - [Regular](https://github.com/googlefonts/noto-cjk/blob/master/NotoSansCJKsc-Regular.otf)
  - [Bold](https://github.com/googlefonts/noto-cjk/blob/master/NotoSansCJKsc-Bold.otf)
  - [Black](https://github.com/googlefonts/noto-cjk/blob/master/NotoSansCJKsc-Black.otf)

**【思源宋体 / Noto Serif】**

  - [Regular](https://github.com/googlefonts/noto-cjk/blob/master/NotoSerifCJKsc-Regular.otf)
  - [Bold](https://github.com/googlefonts/noto-cjk/blob/master/NotoSerifCJKsc-Bold.otf)
  - [Black](https://github.com/googlefonts/noto-cjk/blob/master/NotoSerifCJKsc-Black.otf)
